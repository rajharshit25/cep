// Shared utilities for StudySaathi 2.0

const loadFromStorage = (key, defaultValue) => {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : defaultValue;
  } catch (e) {
    console.error(`Error loading ${key}:`, e);
    return defaultValue;
  }
};

const saveToStorage = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error saving ${key}:`, e);
  }
};

const playSound = (type) => {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const osc = ctx.createOscillator();
  osc.type = type === 'start' ? 'sine' : type === 'pause' ? 'square' : 'triangle';
  osc.frequency.setValueAtTime(type === 'start' ? 440 : type === 'pause' ? 220 : 660, ctx.currentTime);
  osc.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 0.3);
};

const motivationalMessages = [
  "Great job! You're crushing it! 🚀",
  "Keep it up, champ! You've got this! 💪",
  "One step closer to your goals! 😊",
  "Amazing work! Stay focused! 🌟",
  "You're unstoppable today! 🔥"
];

const getRandomMotivation = () => {
  return motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
};

const formatTime = (seconds) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
};

const formatDateTime = (date) => {
  const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
  const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  return {
    time: date.toLocaleTimeString('en-US', timeOptions),
    date: date.toLocaleDateString('en-US', dateOptions)
  };
};

const showMotivationMessage = (elementId, message) => {
  const element = document.getElementById(elementId);
  if (element) {
    element.textContent = message;
    element.classList.remove('hidden');
    setTimeout(() => {
      element.classList.add('hidden');
    }, 3000);
  }
};

const priorityColors = {
  high: 'bg-red-100 border-red-500 text-red-700',
  medium: 'bg-yellow-100 border-yellow-500 text-yellow-700',
  low: 'bg-green-100 border-green-500 text-green-700'
};

// Initialize default stats if not exists
const getDefaultStats = () => ({
  xp: 0,
  streak: 0,
  totalHours: 0,
  totalSessions: 0,
  longestSession: 0,
  goal: 0,
  subjectHours: {},
  breathingCycles: {},
  tasksCompleted: 0,
  tasksCompletedToday: {},
  hoursToday: {},
  bestStreak: 0
});

